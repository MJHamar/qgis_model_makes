# -*- coding: utf-8 -*-
"""
/***************************************************************************
 TerrainModelMaker
                                 A QGIS plugin
 Creates laser cuttable terrain models from contour data
                              -------------------
        begin                : 2023-09-15
        git sha              : $Format:%H$
        copyright            : (C) 2023 by Miklos Hamar
        email                : szad5615@gmail.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

import os
import tempfile
from qgis.core import (
    QgsProject,
    QgsVectorLayer,
    QgsFeature,
    QgsFeatureRequest,
    QgsExpression,
    QgsExpressionContext,
    QgsExpressionContextUtils,
    QgsGeometry,
    QgsRectangle,
    QgsCoordinateTransform,
    QgsCoordinateReferenceSystem,
    QgsVectorFileWriter,
    QgsField,
    QgsFields,
    QgsWkbTypes
)
from PyQt5.QtCore import QVariant

def find_contour_layer(project=None):
    """
    Find a contour layer in the current project.
    
    :param project: QgsProject instance, uses the current project if None
    :return: The contour layer or None if not found
    """
    if project is None:
        project = QgsProject.instance()
    
    # Potential contour layer names
    contour_names = ["contour", "elevation", "isoline"]
    
    # Check for layers with these names
    for layer_id, layer in project.mapLayers().items():
        if isinstance(layer, QgsVectorLayer) and layer.geometryType() == QgsWkbTypes.LineGeometry:
            layer_name = layer.name().lower()
            
            # Direct match with known contour layer names
            if any(name in layer_name for name in contour_names):
                return layer
            
            # Check if layer has elevation or altitude field
            fields = [field.name().lower() for field in layer.fields()]
            if any(name in ' '.join(fields) for name in ["elev", "alt", "height", "z"]):
                return layer
    
    return None

def filter_contours_by_interval(input_layer, interval, region_rect=None, elevation_field=None):
    """
    Filter contour lines to keep only those at the specified elevation interval.
    
    :param input_layer: Input contour QgsVectorLayer
    :param interval: Elevation interval to filter by (e.g., 5 for every 5 meter contour)
    :param region_rect: Optional QgsRectangle to filter by region
    :param elevation_field: Name of the field containing elevation values, will try to detect if None
    :return: A new in-memory layer with filtered contours
    """
    if not input_layer or not input_layer.isValid():
        return None
    
    # Detect elevation field if not specified
    if elevation_field is None:
        possible_names = ["elev", "elevation", "alt", "altitude", "height", "z", "level"]
        for field in input_layer.fields():
            field_name = field.name().lower()
            if any(name in field_name for name in possible_names):
                elevation_field = field.name()
                break
        
        # If still not found, try to use the first numeric field
        if elevation_field is None:
            for field in input_layer.fields():
                if field.type() in [QVariant.Int, QVariant.Double, QVariant.LongLong]:
                    elevation_field = field.name()
                    break
    
    if elevation_field is None:
        raise ValueError("Could not detect elevation field in contour layer")
    
    # Create an expression to filter by elevation interval
    expression = f"{elevation_field} % {interval} = 0"
    
    # Create a request to filter by expression and region
    request = QgsFeatureRequest()
    request.setFilterExpression(expression)
    
    # If region is specified, filter spatially
    if region_rect:
        # Ensure rectangle is in the layer's CRS
        if region_rect.crs().authid() != input_layer.crs().authid():
            transform = QgsCoordinateTransform(
                region_rect.crs(),
                input_layer.crs(),
                QgsProject.instance()
            )
            region_rect_transformed = transform.transformBoundingBox(region_rect)
            request.setFilterRect(region_rect_transformed)
        else:
            request.setFilterRect(region_rect)
    
    # Create a new memory layer to store filtered contours
    filtered_layer = QgsVectorLayer(
        f"LineString?crs={input_layer.crs().authid()}",
        f"Filtered Contours ({interval}m)",
        "memory"
    )
    
    # Copy fields from input layer
    filtered_layer.dataProvider().addAttributes(input_layer.fields())
    filtered_layer.updateFields()
    
    # Extract filtered features
    filtered_layer.startEditing()
    for feature in input_layer.getFeatures(request):
        filtered_layer.addFeature(feature)
    filtered_layer.commitChanges()
    
    return filtered_layer

def export_contours_to_file(layer, output_path, format="CSV"):
    """
    Export contour lines to a file for laser cutting.
    
    :param layer: QgsVectorLayer containing contour lines
    :param output_path: Path to save the output file
    :param format: Output format ("CSV", "DXF", or "SVG")
    :return: True if successful, False otherwise
    """
    if not layer or not layer.isValid():
        return False
    
    # Create the output directory if it doesn't exist
    output_dir = os.path.dirname(output_path)
    if output_dir and not os.path.exists(output_dir):
        os.makedirs(output_dir)
    
    if format.upper() == "CSV":
        # For CSV, we'll create a text file with coordinates
        try:
            with open(output_path, 'w') as f:
                # Write header
                f.write("elevation,part,x,y\n")
                
                # Process features
                for feature in layer.getFeatures():
                    geom = feature.geometry()
                    if geom.isMultipart():
                        # Handle multipart geometries (multiple lines per feature)
                        for part_idx, part in enumerate(geom.asMultiPolyline()):
                            for point in part:
                                f.write(f"{feature['elevation']},{part_idx},{point.x()},{point.y()}\n")
                    else:
                        # Handle single part geometries
                        for point in geom.asPolyline():
                            f.write(f"{feature['elevation']},0,{point.x()},{point.y()}\n")
            return True
        except Exception as e:
            print(f"Error exporting to CSV: {e}")
            return False
            
    elif format.upper() == "DXF":
        # For DXF, use QgsVectorFileWriter
        options = QgsVectorFileWriter.SaveVectorOptions()
        options.driverName = "DXF"
        
        # Export to DXF
        error = QgsVectorFileWriter.writeAsVectorFormatV2(
            layer, 
            output_path, 
            QgsCoordinateTransform(), 
            options
        )
        
        return error[0] == QgsVectorFileWriter.NoError
        
    elif format.upper() == "SVG":
        # For SVG, we'll create a simple SVG file with contour lines
        try:
            # Get layer extent
            extent = layer.extent()
            width = extent.width()
            height = extent.height()
            
            # Compute scaling to fit SVG canvas (assumed 800x600)
            svg_width = 800
            svg_height = 600
            scale_x = svg_width / width if width > 0 else 1
            scale_y = svg_height / height if height > 0 else 1
            scale = min(scale_x, scale_y) * 0.9  # 90% to leave margin
            
            # Compute translation to center in SVG canvas
            translate_x = svg_width / 2 - scale * (extent.xMinimum() + width / 2)
            translate_y = svg_height / 2 + scale * (extent.yMinimum() + height / 2)
            
            # Start SVG file
            with open(output_path, 'w') as f:
                f.write(f'<?xml version="1.0" encoding="UTF-8" standalone="no"?>\n')
                f.write(f'<svg xmlns="http://www.w3.org/2000/svg" width="{svg_width}" height="{svg_height}">\n')
                
                # Group with transform to adjust coordinates
                f.write(f'<g transform="translate({translate_x},{translate_y}) scale({scale},-{scale})">\n')
                
                # Process each contour line
                for feature in layer.getFeatures():
                    geom = feature.geometry()
                    elev = feature['elevation']
                    
                    # Get path data for SVG
                    path_data = ""
                    
                    if geom.isMultipart():
                        # Handle multipart geometries
                        for part in geom.asMultiPolyline():
                            if part:
                                path_data += f"M {part[0].x()},{part[0].y()} "
                                for point in part[1:]:
                                    path_data += f"L {point.x()},{point.y()} "
                    else:
                        # Handle single part geometries
                        line = geom.asPolyline()
                        if line:
                            path_data += f"M {line[0].x()},{line[0].y()} "
                            for point in line[1:]:
                                path_data += f"L {point.x()},{point.y()} "
                    
                    # Write path element with elevation as label
                    f.write(f'<path d="{path_data}" fill="none" stroke="black" stroke-width="0.5" id="contour_{elev}" />\n')
                
                # Close group and SVG
                f.write('</g>\n')
                f.write('</svg>\n')
                
            return True
        except Exception as e:
            print(f"Error exporting to SVG: {e}")
            return False
    
    else:
        print(f"Unsupported export format: {format}")
        return False 